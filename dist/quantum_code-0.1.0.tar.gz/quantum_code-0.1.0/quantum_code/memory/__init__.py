# Memory module for conversation state management
